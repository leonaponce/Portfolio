// coded by Leona Ponce
const projectName = 'portfolio';
localStorage.setItem('example_project', 'Personal Portfolio');